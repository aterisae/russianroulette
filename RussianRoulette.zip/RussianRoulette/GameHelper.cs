public static class GameHelper
{
    public static void FearCheck()
    {
        bool isNotAfraid = false;
        while (!isNotAfraid)
        {
            Console.WriteLine("Вы боитесь?");
            string answer = Console.ReadLine()!.ToLower();
            
            if (answer == "нет" || answer == "не")
            {
                Console.WriteLine("Не ври.");
            }
            else
            {
                Console.WriteLine("НЕ БОЙСЯ");
                isNotAfraid = true;
            }
        }
    }

    public static string GetPlayerName(bool isChildMode)
    {
        Console.WriteLine("Введите имя игрока: ");
        string playerName = Console.ReadLine()!;
        
        if (playerName == GameConstants.BotName)
        {
            string defaultName = isChildMode ? "Сынок" : "Даун";
            Console.WriteLine($"ТАК НЕ ПОЙДЕТ! Будешь {defaultName}.");
            return defaultName;
        }
        
        return playerName;
    }
}