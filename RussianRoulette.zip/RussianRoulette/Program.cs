﻿using System.Globalization;
using System.Text;

class Program
{
    static void Main()
    {
        SetupConsole();
        
        Console.WriteLine("Выберите режим:\n1-PvP\n2-с ботом\n3-с ботом для детей");
        
        int choice;
        while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 3)
        {
            Console.WriteLine("Введите число от 1 до 3!");
        }

        switch (choice)
        {
            case 1:
                new GameEngine(false, false).StartGame();
                break;
            case 2:
                new GameEngine(false, true).StartGame();
                break;
            case 3:
                new GameEngine(true, true).StartGame();
                break;
        }
    }

    private static void SetupConsole()
    {
        var cultureInfo = new CultureInfo("ru-RU");
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        var enc1251 = Encoding.GetEncoding(1251);
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = enc1251;
    }
}