public class GameEngine
{
    private readonly bool _isChildMode;
    private readonly bool _isBotMode;
    private readonly Random _random = new();
    
    private string _player1;
    private string _player2;
    private double _betAmount;
    private int _bulletPosition;
    private int _currentChamber;
    private bool _gameActive;

    public GameEngine(bool isChildMode, bool isBotMode)
    {
        _isChildMode = isChildMode;
        _isBotMode = isBotMode;
        
        InitializeGame();
    }

    private void InitializeGame()
    {
        GameHelper.FearCheck();
        CurrencyConverter.ConvertBet(out _betAmount, _isChildMode);
        
        _player1 = GameHelper.GetPlayerName(_isChildMode);
        _player2 = _isBotMode ? GameConstants.BotName : GetSecondPlayerName();
        
        _bulletPosition = _random.Next(1, GameConstants.ChamberSize + 1);
        _currentChamber = _random.Next(1, GameConstants.ChamberSize + 1);
        _gameActive = true;
    }

    private string GetSecondPlayerName()
    {
        Console.WriteLine("Введите имя второго игрока: ");
        return Console.ReadLine()!;
    }

    public void StartGame()
    {
        var players = new Queue<string>(new[] { _player1, _player2 });

        while (_gameActive)
        {
            var currentPlayer = players.Dequeue();
            players.Enqueue(currentPlayer);
            
            PlayTurn(currentPlayer);
        }
    }

    private void PlayTurn(string player)
    {
        if (!_gameActive) return;

        Console.WriteLine($"Сейчас очередь {player}");
        
        int action = player == GameConstants.BotName ? GetBotAction() : GetPlayerAction();
        
        switch (action)
        {
            case 1: Shoot(player); break;
            case 2: SpinChamber(player); break;
            case 3: TryEscape(player); break;
            case 4: ShootOpponent(player); break;
        }
    }

    private int GetPlayerAction()
    {
        Console.WriteLine("Выберите действие:");
        Console.WriteLine("1-Выстрел\n2-Прокрут барабана\n3-Сбежать\n4-Выстрелить в оппонента");
        
        int choice;
        while (true)
        {
            if (int.TryParse(Console.ReadLine(), out choice) && choice >= 1 && choice <= 4)
            {
                return choice;
            }
            Console.WriteLine(_isChildMode 
                ? "Пожалуйста, выбери доступное число!" 
                : "Выберите число от 1 до 4!");
        }
    }

    private int GetBotAction()
    {
        double chance = _random.NextDouble();
        return chance switch
        {
            < 0.97 => 1,
            < 0.98 => 2,
            < 0.99 => 3,
            _ => 4
        };
    }

    private void Shoot(string player, bool isOpponentShot = false)
    {
        Console.WriteLine(isOpponentShot 
            ? $"Выстрел в оппонента!" 
            : $"Ствол у виска. Выстрел!");

        if (_bulletPosition == _currentChamber)
        {
            _gameActive = false;
            HandleLose(player, isOpponentShot);
        }
        else
        {
            Console.WriteLine($"{player} остался жив");
        }
        
        AdvanceChamber();
    }

    private void AdvanceChamber()
    {
        _currentChamber++;
        if (_currentChamber > GameConstants.ChamberSize)
        {
            _currentChamber = 1;
        }
    }

    private void SpinChamber(string player)
    {
        _currentChamber = _random.Next(1, GameConstants.ChamberSize + 1);
        Console.WriteLine("Барабан прокручен.");
        Shoot(player);
    }

    private void TryEscape(string player)
    {
        _gameActive = false;
        Console.WriteLine("При попытке побега...");
        
        if (_random.Next(1, 11) <= 7)
        {
            string winner = player == _player1 ? _player2 : _player1;
            string weapon = _isChildMode ? "водного пистолета" : "карманного Fokker-Leimberger";
            
            Console.WriteLine($"{player} был застрелен в спину из {weapon}");
            HandleWin(winner, player);
        }
        else
        {
            Console.WriteLine(_isChildMode
                ? $"{player} успешно сбежал и остался без конфет"
                : $"{player} успешно сбежал и потерял деньги");
        }
    }

    private void ShootOpponent(string player)
    {
        if (_bulletPosition != _currentChamber)
        {
            _gameActive = false;
            Console.WriteLine(_isChildMode 
                ? ".....с пелёнок уже крыса" 
                : ".....вам раскрошили еблище");
            
            string winner = player == _player1 ? _player2 : _player1;
            HandleWin(winner, player);
        }
        else
        {
            Console.WriteLine(_isChildMode
                ? $"Успех! {player} облил водой оппонента и теперь ему запрещен вход в детский сад! У него конфисковали все конфеты!"
                : $"Успех! {player} убил оппонента и теперь ему запрещен вход в данное заведение! У него конфисковали все деньги!");
            _gameActive = false;
        }
    }

    private void HandleLose(string loser, bool isOpponentShot)
    {
        string winner = loser == _player1 ? _player2 : _player1;
        
        Console.WriteLine(_isChildMode
            ? $"{loser} облился"
            : $"{loser} застрелился");
        
        HandleWin(winner, loser, isOpponentShot);
    }

    private void HandleWin(string winner, string loser, bool isOpponentShot = false)
    {
        double prize = _betAmount * (1 - GameConstants.TaxRate);
        string currency = _isChildMode ? "конфет" : "руб.";
        
        Console.WriteLine(isOpponentShot
            ? $"{winner} одержал победу над {loser} и получает выигрыш в размере {prize:f2} {currency}."
            : $"{winner} одержал победу над {loser} и получает выигрыш в размере {prize:f2} {currency}.");
    }
}