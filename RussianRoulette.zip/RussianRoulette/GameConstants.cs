public static class GameConstants
{
    public const double TaxRate = 14.88 / 100;
    public const int ChamberSize = 6;
    public const string BotName = "БОТ НИКАНОР";
}