public static class CurrencyConverter
{
    public static double ConvertBet(out double betAmount, bool isChildMode = false)
    {
        if (isChildMode)
        {
            return ConvertCandyBet(out betAmount);
        }
        else
        {
            return ConvertMoneyBet(out betAmount);
        }
    }

    private static double ConvertMoneyBet(out double money)
    {
        Console.WriteLine("Сколько рублей ставите?");
        money = double.Parse(Console.ReadLine()!);
        
        Console.WriteLine("Выберите валюту:");
        Console.WriteLine("1 - Рубли\n2 - Монгольские тугрики\n3 - Доллары\n4 - Тенге");
        int currencyChoice = int.Parse(Console.ReadLine()!);
        
        switch (currencyChoice)
        {
            case 2: money *= 0.0256; break;  // Тугрики
            case 3: money *= 90; break;      // Доллары
            case 4: money /= 5; break;      // Тенге
        }
        
        return money;
    }

    private static double ConvertCandyBet(out double candyAmount)
    {
        Console.WriteLine("Сколько конфет ставите?");
        candyAmount = double.Parse(Console.ReadLine()!);
        
        Console.WriteLine("Выберите тип конфет:");
        Console.WriteLine("1 - Очень вкусные\n2 - Вкусные\n3 - Не очень вкусные\n4 - Очень невкусные");
        int candyType = int.Parse(Console.ReadLine()!);
        
        switch (candyType)
        {
            case 1: candyAmount += 10; break;
            case 2: candyAmount *= 2; break;
            case 3: candyAmount /= 2; break;
            case 4: candyAmount /= 10; break;
        }
        
        return candyAmount;
    }
}